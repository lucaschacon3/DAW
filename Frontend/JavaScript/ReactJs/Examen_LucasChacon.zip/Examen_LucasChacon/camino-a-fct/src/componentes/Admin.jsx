import "../estilos/cuerpo.css";
import { ToastContainer, toast } from "react-toastify";

// Datos de imágenes

// Componente ListaImagenes
const Admin = () => {


  return (
    <h1>Bienvenido admin</h1>
  );
};

export default Admin;
